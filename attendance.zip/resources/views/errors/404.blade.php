@extends("layouts.index")

@section("title", "Index page")

@section("content")

{{-- Account unauthorized/unverified message --}}
<div class="box">
    <p class="has-text-centered">۴۰۴ صفحه مورد نظر یافت نشد</p>
</div>

@endsection
