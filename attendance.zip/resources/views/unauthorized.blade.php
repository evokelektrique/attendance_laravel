@extends("layouts.index")

@section("title", "Index page")

@section("content")

{{-- Account unauthorized/unverified message --}}
<div class="box">
    <p class="has-text-centered">اکانت شما تایید نشده است</p>
</div>

@endsection
